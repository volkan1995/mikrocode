<?php
    if(!defined('m_guvenlik')) { exit; }
    
    $mapi_result['api_test'] = $mapi_dil[12];
    
    $mapi_result['api_id'] = $m_api['kod'];
    
    $mapi_result['api_key'] = $m_api['anahtar'];
    
    $mapi_result['api_use'] = $m_api['istek'];
    
    $mapi_result['api_client'] = $m_api['istemci'];